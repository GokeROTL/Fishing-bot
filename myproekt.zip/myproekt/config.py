token = '8106509641:AAEeCkDd7VFi_CELULk_bHtmFwzeBVC8yeU' # Токен бота
loginbot = 'Snoo000sssss_bot' # Логин бота телеграм

admin_id = 7525671125 # Ваш айди

price = "1 день-200\n7 дней-400\n30 дней-600\n180 дней-1600\n365 дней-4000"