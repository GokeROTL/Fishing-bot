import config
import keyboard
import re
import telebot

from telebot import types

from telebot.types import ReplyKeyboardMarkup, KeyboardButton

import smtplib

from email.mime.text import MIMEText

from email.mime.multipart import MIMEMultipart

from datetime import datetime, timedelta

import sqlite3

from database.base import *

from pyCryptoPayAPI import pyCryptoPayAPI

import json

import requests

import random

import time

import config as cfg

subscribers = {}



conn = sqlite3.connect('subscription.db')

cursor = conn.cursor()

cursor.execute('''

    CREATE TABLE IF NOT EXISTS users (

        user_id INTEGER PRIMARY KEY,

        expiration_date TEXT

    )

''')

conn.commit()

crypto = pyCryptoPayAPI(api_token="305330:AATll4oS3bdlkLVo4HYMx0krEeKOrP4dmC0")

bot_token = '8106509641:AAEeCkDd7VFi_CELULk_bHtmFwzeBVC8yeU'

owner_id = "7525671125"

channel_id = '-1002422140418'  # ID вашего канала

channel_username = 'UZI_Tool'  # Имя вашего канала без "@"

name_bot = 'UZITool_bot' #имя бота

bot = telebot.TeleBot(bot_token)

admins = ["7525671125"]
last_raid_time = {}

















def load_users():

    try:

        with open('users.txt', 'r') as file:

            return [int(line.strip()) for line in file]

    except FileNotFoundError:

        return []



def save_user(user_id):

    users = load_users()

    if user_id not in users:

        users.append(user_id)

        with open('users.txt', 'w') as file:

            file.write('\n'.join(str(user) for user in users))





def create_users_table(cursor):

    cursor.execute('''

        CREATE TABLE IF NOT EXISTS users (

            id INTEGER PRIMARY KEY,

            username TEXT,

            last_interaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL

        )

    ''')



def update_database():

    with sqlite3.connect('database.db') as connection:

        cursor = connection.cursor()



        # Create the users table if it doesn't exist

        create_users_table(cursor)



        # Проверка на наличие столбца last_interaction

        cursor.execute("PRAGMA table_info(users)")

        columns = [column[1] for column in cursor.fetchall()]

        if "last_interaction" not in columns:

            cursor.execute('''

                ALTER TABLE users ADD COLUMN last_interaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL

            ''')

            connection.commit()



update_database()





@bot.message_handler(commands=['start'])

def start(message):

    user_id = message.from_user.id

    if message.text == '/start':

        save_user(user_id)

    user_id = message.from_user.id

    is_subscribed = True

    # Проверяем наличие активной подписки у пользователя

    with sqlite3.connect('subscriptions.db') as conn:

        cursor = conn.cursor()

        cursor.execute('SELECT expiration_date FROM users WHERE user_id = ?', (user_id,))

        result = cursor.fetchone()



    if result:

        expiration_date = datetime.strptime(result[0], "%Y-%m-%d").date()

        if expiration_date >= datetime.now().date():

            is_subscribed = True



    if is_subscribed:



        photo_path = 'neta.jpg'  # Путь к вашей фотографии для подписанных пользователей

        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
        with open(photo_path, 'rb') as photo:

            bot.send_photo(message.chat.id, photo,

                           caption='''`пиши юз, айди, айпи, фио или что то про типа одним соо, и я найду его данные
                УДАЧИ`''',

                           reply_markup=markup, parse_mode="Markdown")

    else:

        # Если подписки у пользователя нет, создаем счет для оплаты подписки

        invoice = crypto.create_invoice(asset='USDT', amount=2)

        pay_url = invoice['pay_url']

        invoice_id = invoice['invoice_id']

        keyboard = types.InlineKeyboardMarkup()

        keyboard.add(types.InlineKeyboardButton("Купить Подписку (2$)", url=pay_url))

        keyboard.add(types.InlineKeyboardButton("Проверить оплату", callback_data=f"check_status_{invoice_id}"))



        photo_path = 'neta1.png'  # Путь к вашей фотографии

        with open(photo_path, 'rb') as photo:

            bot.send_photo(message.chat.id, photo,

                           caption=f"Привествую!\nUZI-Tool - уникальный бот для де@н0н@, св@т@, сн0с@ и прочее\nЦена подписки навсегда - 2$\nКанал с новостями: https://t.me/ILov3Y0uSNOS\nЧтобы купить ее, перейдите по ссылке ниже",

                           reply_markup=keyboard),





@bot.callback_query_handler(func=lambda c: c.data.startswith('check_status'))

def check_status(callback_query):

    invoice_id = callback_query.data.split('_')[2]

    old_invoice = crypto.get_invoices(invoice_ids=invoice_id)

    status_old_invoice = old_invoice['items'][0]['status']

    user_id = callback_query.from_user.id



    if status_old_invoice == "paid":

        bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)

        bot.send_message(user_id, f"Спасибо за оплату!")



        # Добавляем пользователя в базу данных как подписчика

        with sqlite3.connect('subscriptions.db') as conn:

            cursor = conn.cursor()

            expiration_date = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")  # Предположим, что подписка действует 30 дней

            cursor.execute('INSERT OR REPLACE INTO users (user_id, expiration_date) VALUES (?, ?)', (user_id, expiration_date))

            conn.commit()



        # Отправляем сообщение пользователю о том, что подписка активирована

        bot.send_message(user_id, "Подписка успешно активирована!")

    elif status_old_invoice == "active":

        bot.send_message(user_id, f"Вы не оплатили счет!")

    else:

        bot.send_message(user_id, f"Счет {invoice_id} не найден.")










        
@bot.message_handler(commands=['balance']) 
def send_welcome(message):
	if message.chat.id == config.admin_id:
		word = ['Мм.. Запах денег..', 'Ну, посмотрим что тут у нас..', 'Money-money!', 'Слишком большие суммы на кошельке', 'Так, что у нас тут', 'Да прибудет с тобой удача']
		bot.send_message(message.chat.id,'💁‍♀️ '+random.choice(word)+'\n\nНомер - `'+config.QIWI_NUMBER+'`\nТокен - `'+config.QIWI_TOKEN+'`\nБаланс - `'+str(apiqiwi.balance[0])+'₽`', parse_mode='Markdown')
	else:
		bot.send_message(message.chat.id,'Вы не туда попали 🤒')
@bot.message_handler(content_types=['text'])
def message(message):
	if message.text == '🆘 Команды':
		bot.send_message(message.chat.id, 'отправь что нибудь про типа, и мы найдём его данные ', parse_mode='Markdown')
	elif message.text == '📓 Руководство':
		bot.send_message(message.chat.id, '*👁 Руководство по работе с платформой UZI-Tool.*\n└ Данное руководство описывает популярные функции поиска и работу с ними.', reply_markup=keyboard.inline_manual, parse_mode='Markdown')
	elif message.text == '👤 Мой аккаунт':
		bot.send_message(message.chat.id, 'Подпишись на наш telegram канал\nhttps://t.me/UZI_Tool\n\nВаш ID: `'+str(message.chat.id)+'`\nЮзернейм: `@'+str(message.chat.username)+'`\n\n📅 Подписка:  `есть`\n💵 Внутренний баланс: `не ебу скок`', parse_mode='Markdown')
	elif message.text == '👁 О сервисе':
		bot.send_message(message.chat.id, '👁 Глаз Бога - система по поиску информации с огромным количеством возможностей.\n\nСервис позволяет получать информацию о физических лицах в режиме реального времени. *Работа ведётся в рамках Федерального закона от 27 июля 2006 г. № 152-ФЗ «О персональных данных»*, в соответствии с которым обработка персональных данных осуществляется *только с согласия субъекта* персональных данных.\n\n📩 Сотрудничество: ad@eyeofgod.info\n🛡 Юридический отдел: law@eog.pw\n⚙️ Служба поддержки: tech@eog.pw\n📰 Пресс-центр: agent@eog.pw\n👮‍♂️ Гос. и правоохранительным органам: gov@eog.pw', reply_markup=keyboard.inline_about, parse_mode='Markdown')
	else:
		bot.send_message(message.chat.id, '⏳ Обрабатываю запрос..')
		a = random.randint(4,7)
		time.sleep(a)
		bot.send_message(message.chat.id, '👀 Ты не оплатил.')
		time.sleep(1)
		bot.send_message(message.chat.id, '*Раз хотел попользоваться ботом, тогда покупай подписку!*\nСтоимость `'+str(config.price)+'₽`', reply_markup=keyboard.inline_buy, parse_mode='Markdown')
@bot.message_handler(content_types=['document'])
def document_react(message):
	bot.send_message(message.chat.id, '⏳ Обрабатываю запрос..')
	a = random.randint(4,7)
	time.sleep(a)
	bot.send_message(message.chat.id, '👀 Ты не оплатил')
	time.sleep(1)
	bot.send_message(message.chat.id, '*Раз хотел попользоваться ботом, тогда покупай подписку!*\nСтоимость `'+str(config.price)+'₽`', reply_markup=keyboard.inline_buy, parse_mode='Markdown')
@bot.callback_query_handler(func=lambda call: True)
def step_buy(call):
	if call.data == 'buying':
   
        
             #ТУТ ОПЛАТА     
    	invoice = crypto.create_invoice(asset='USDT', amount=2)

    pay_url = invoice['pay_url']

    invoice_id = invoice['invoice_id']

    keyboard = types.InlineKeyboardMarkup()

    keyboard.add(types.InlineKeyboardButton("Купить Подписку (2$)", url=pay_url))

    keyboard.add(types.InlineKeyboardButton("Проверить оплату", callback_data=f"check_status_{invoice_id}"))



        photo_path = 'neta1.png'  # Путь к вашей фотографии

        with open(photo_path, 'rb') as photo:

            bot.send_photo(message.chat.id, photo,

                           caption=f"Нажимай на кнопку оплатить, отправляей дэнгу, и пользуйся ботом с радостью]]",

                           reply_markup=keyboard),





@bot.callback_query_handler(func=lambda c: c.data.startswith('check_status'))

def check_status(callback_query):

    invoice_id = callback_query.data.split('_')[2]

    old_invoice = crypto.get_invoices(invoice_ids=invoice_id)

    status_old_invoice = old_invoice['items'][0]['status']

    user_id = callback_query.from_user.id



    if status_old_invoice == "paid":

        bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)

        bot.send_message(user_id, f"Спасибо за оплату!")



        # Добавляем пользователя в базу данных как подписчика

        with sqlite3.connect('subscriptions.db') as conn:

            cursor = conn.cursor()

            expiration_date = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")  # Предположим, что подписка действует 30 дней

            cursor.execute('INSERT OR REPLACE INTO users (user_id, expiration_date) VALUES (?, ?)', (user_id, expiration_date))

            conn.commit()



        # Отправляем сообщение пользователю о том, что подписка активирована

        bot.send_message(user_id, "Подписка успешно активирована!")

    elif status_old_invoice == "active":

        bot.send_message(user_id, f"Вы не оплатили счет!")

    else:

        bot.send_message(user_id, f"Счет {invoice_id} не найден.")












if __name__ == '__main__':
	bot.polling(none_stop=True)